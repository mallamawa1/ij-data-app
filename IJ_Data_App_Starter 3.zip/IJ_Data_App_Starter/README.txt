# I J Data — starter app

This is a mobile-friendly progressive web app starter for an intended Nigerian data and airtime business.

## Included
- Responsive I J Data homepage
- Data and airtime form interactions
- Network selector: MTN, Airtel, Glo, 9mobile
- Demo order review and local session history
- PWA manifest and service worker starter

## Important
This is a FRONT-END DEMO only. It does not process money, send data, or connect to a VTU provider. Sample bundle prices are placeholders and must be replaced with verified current prices.

Before taking real orders:
1. Choose and verify a VTU provider that offers API access for data and airtime.
2. Build a secure server/backend to keep API keys secret and validate transactions.
3. Connect a payment gateway and verify payment server-side before fulfilment.
4. Add order IDs, idempotency, error handling, refunds/reversals, support contact and privacy terms.
5. Test with small amounts and confirm the provider's terms, pricing, fees and settlement process.
6. Host over HTTPS. The PWA install prompt/service worker require a secure origin (or localhost).
7. Publishing native apps in Google Play and Apple App Store has separate account, policy and fee requirements.

## Preview
Open `index.html` in a browser to inspect the interface. For installable PWA behaviour, deploy the files to an HTTPS static host.
